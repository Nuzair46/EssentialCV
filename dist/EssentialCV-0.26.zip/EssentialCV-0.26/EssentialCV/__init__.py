'''
	Author: Rednek46 - Nuzair Rasheed
	---------------------------------
	This is a simplified module for the great OpenCV Library.
	Most of the essential functions in the library are condensed to a minimal and easy to understand code.
'''
from EssentialCV.essentials import *